a) to check your lcd is working properly load lcd_controller.svf on krypton after plug in lcd.
   it should continuously display (ABCD....45) and clear it in the end.