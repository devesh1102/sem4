This python script converts TRACEFILE.txt to JTAG_tracefile.

python convert_tracefile_to_jtag_trace.py TRACEFILE.txt in.txt 3 8
