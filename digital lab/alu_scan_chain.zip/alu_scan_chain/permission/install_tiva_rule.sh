cp 99-tiva.rules /etc/udev/rules.d
